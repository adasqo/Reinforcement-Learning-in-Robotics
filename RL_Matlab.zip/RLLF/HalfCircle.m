function [xn, yn] = HalfCircle(centre, radius, nPoints, half)
%Funkcja tworzy polokrag o srodku w pkt centre, promieniu radius - n_points punktach 

    theta = linspace(0,2*pi, nPoints);
    rho = ones(1, nPoints)*radius;
    [x, y] = pol2cart(theta, rho);
    x = x + centre(1);
    y = y + centre(2);
    
    xn = zeros(1, nPoints/2);
    yn = zeros(1, nPoints/2);
    
    %1 polowa
    if(half == 1)
        xn(1:nPoints/4) = x(3/4*nPoints+1:nPoints);
        xn(nPoints/4+1:nPoints/2) = x(1:nPoints/4);
        yn(1:nPoints/4) = y(3/4*nPoints+1:nPoints);
        yn(nPoints/4+1:nPoints/2) = y(1:nPoints/4);
    %2 polowa
    elseif(half == 2)
        xn = x(1:nPoints/2);
        yn = y(1:nPoints/2);
    %3 polowa
    elseif(half == 3)
        xn = x(nPoints/4 + 1:nPoints*3/4);
        yn = y(nPoints/4 + 1:nPoints*3/4);
    %4 polowa
    elseif(half == 4)
        xn = x(nPoints/2 + 1:nPoints);
        yn = y(nPoints/2 + 1:nPoints);        
    end
end