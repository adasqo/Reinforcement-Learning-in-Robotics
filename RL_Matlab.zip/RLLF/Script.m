%Glowny skrypt programu
clc; clear all;

%Wczytanie parametrow
Parameters;

while(true)

    %Petla okreslajaca liczbe przejazdow
    while(i < maxTrials && flag == 1)

        %Inicjalizacja zmiennych
        phi = 0;
        iterRange = 0;  
        k = 0;
        
        %Poczatkowe sprawdzenie czujnikow
        [sensors, colors] = CheckLine(agent, path, pathWidth, pathLength);

        %Poczatkowa dyskretyzacja 
        state = Discretization(sensors, stateSpace);
        
        %Petla czasowa w pojedynczym przejezdzie   
        while(k < maxSteps && flag == 1)

            if(sqrt((pos(1) - posInit(1))^2 + (pos(2) - posInit(2))^2) < 2 && k > 100)
                flag = 0;
                break;
            end
            
            %Wybor akcji
            action = ChooseAction(QTable, state, actions, T, eps);

            %Okreslenie polozenia agenta i rysowanie go na plaszczyznie
            [phi, pos] = DrawAgent(agent, action, colors, phi, pos, beta, velocity);
            
            %Sprawdzenie wartosci z czujnikow po wykonanej akcji
            [sensors, colors] = CheckLine(agent, path, pathWidth, pathLength);
            
            %Dyskretyzacja po wykonanym ruchu
            nextState = Discretization(sensors, stateSpace);  

            %Sprawdzenie, czy agent znajduje sie nad linia
            ifInRange = OutOfRange(sensors);

            %Jesli agent jest poza torem - zwieksz licznik iterRang, jesli
            %nie - wyzeruj
            if(ifInRange == 0)
                iterRange = iterRange + 1;
            else
                iterRange = 0;
            end

            %Jesli agent znajduje sie poza torem przez kilka krokow, ustaw
            %flage
            if(iterRange == 3)
                ifOut = 1;
            else
                ifOut = 0;
            end
            
            %Przyzawanie nagrody 
            reward = Reward(sensors, iterRange, ifOut);

            %Odswiezenie tablicy Q-wartosci
            QTable = UpdateQTable(state, action, reward, QTable, nextState, alpha, gamma);

            %Przypisanie aktualnego stanu
            state = nextState;

            %Jesli agent znajduje sie poza torem przez kilka krokow, umiera
            if(ifOut == 1)
                break;
            end
                        
            drawnow;
            k = k + 1;
        end 
        i = i + 1;
        delete(agent);
        agent = CreateAgent(radius);
        drawnow;              
    end
end