function a = ChooseAction(QTable, state, actions, T, eps)
%Funkcja wybiera akcje wedlug ustlonej sttategii

    a = SoftMax(QTable, state, actions, T);
    %a = EpsilonGreedy(QTable, state, actions, eps);
    %a = Greedy(QTable, state, actions);
end