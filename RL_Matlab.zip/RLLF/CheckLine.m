function [sensors, colors] = Check(agent, path, pathWidth, pathLength)
%Funkcja sprawdza, czy czujniki agenta znajduja sie nad linia wyznaczajaca
%tor
    
    %Inicjalizacja
    sensors = zeros(5, 1);
    colors = zeros(5, 1);
    iter = 1;
    
    %Dla kazdego czujnika
    for i=2:6
        %Pobranie wektora polozenia czujnika
        R = get(agent(i), 'Vertices');
        Rx = 0.5*(max(R(:, 1)) + min(R(:, 1)));
        Ry = 0.5*(max(R(:, 2)) + min(R(:, 2)));
        
        %Wyznaczenie najkrotszej odleglosci od punktow okreslajacych srodek toru 
        dist = Distance([Rx, Ry], path, pathLength);
        
        %Jesli czujnik znajduje sie w obrebie toru
        if(dist < pathWidth/2)
           sensors(iter) = 1;
           colors(iter) = 'r';
       end
       iter = iter + 1;
    end
end