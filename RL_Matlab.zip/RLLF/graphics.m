clear;clc;

% tab1 = load('eps3.mat', '-mat');
% x1 = tab1.Tab(1, 1:19)
% y1 = tab1.Tab(2, 1:19)
% plot(x1, y1, '.-')
% xlabel('epsilon');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% axis([0 1 0 55]);
% for i = 1:numel(x1)
%     text(x1(i)-0.02, y1(i) + 1.5, sprintf('%.1f', y1(i)));
% end

% tab2 = load('eps10.mat', '-mat');
% x2 = tab2.Tab(1, 1:19)
% y2 = tab2.Tab(2, 1:19)
% plot(x2, y2, '.-')
% xlabel('epsilon');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% axis([0 1 0 55]);
% for i = 1:numel(x2)
%     text(x2(i)-0.02, y2(i) + 1.5, sprintf('%.1f', y2(i)));
% end

% tab4 = load('T3.mat', '-mat');
% x4 = tab4.Tab(1, 1:16);
% y4 = tab4.Tab(2, 1:16);
% z4 = tab4.Tab(3, 1:16);
% plot(x4, y4, '.-')
% xlabel('T');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% axis([0 32 0 55]);
% for i = 1:numel(x4)
%     text(x4(i)-0.5, y4(i) + 1.5, sprintf('%.1f', y4(i)));
% end

% tab3 = load('T10.mat', '-mat')
% x3 = tab3.Tab(1, 1:16);
% y3 = tab3.Tab(2, 1:16);
% plot(x3, y3, '.-')
% xlabel('T');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% axis([0 32 0 55]);
% for i = 1:numel(x3)
%     text(x3(i)-0.5, y3(i) + 1.5, sprintf('%.1f', y3(i)));
% end 

% tab51 = load('alphaT2.mat', '-mat');
% x51 = tab51.Tab(1, 1:19);
% y51 = tab51.Tab(2, 1:19);
% tab52 = load('alphaT10.mat', '-mat');
% x52 = tab52.Tab(1, 1:19);
% y52 = tab52.Tab(2, 1:19);
% tab53 = load('alphaT20.mat', '-mat');
% x53 = [tab53.Tab(1, 1:9), 0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.2, 0.15, 0.1, 0.05];
% y53 = [tab53.Tab(2, 1:9),50*ones([1, 10])];
% tab54 = load('alphaT15.mat', '-mat');
% x54 = [tab54.Tab(1, 1:8), 0.55, 0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.2, 0.15, 0.1, 0.05];
% y54 = [tab54.Tab(2, 1:8),50*ones([1, 11])];
% % tab55 = load('alphaT13.mat', '-mat');
% % x55 = tab55.Tab(1, 1:19);
% % y55 = tab55.Tab(2, 1:19);
% plot(x51, y51, '.-', x52, y52, '.-', x54, y54, '.-', x53, y53, '.-')
% axis([0 1 0 55]);
% legend('T = 2', 'T = 10', 'T = 15', 'T = 20');
% xlabel('alpha');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');

% tab61 = load('gammaT2.mat', '-mat');
% x61 = tab61.Tab(1, 1:19);
% y61 = tab61.Tab(2, 1:19);
% tab62 = load('gammaT10.mat', '-mat');
% x62 = linspace(0.95, 0.05, 19);
% y62 = [tab62.Tab(2, 1:11), 50*ones([1, 8])];
% tab63 = load('gammaT6.mat', '-mat');
% x63 = tab63.Tab(1, 1:19);
% y63 = tab63.Tab(2, 1:19);
% tab64 = load('gammaT15.mat', '-mat');
% x64 = tab64.Tab(1, 1:19);
% y64 = tab64.Tab(2, 1:19);
% plot(x61, y61, '.-', x63, y63, '.-', x62, y62, '.-', x64, y64, '.-');
% axis([0 1 0 55]);
% xlabel('gamma');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% legend('T = 2', 'T = 6', 'T = 10', 'T = 15');

% tab71 = load('alpha&gammaT2.mat', '-mat');
% x71 = tab71.Tab(1, 1:19);
% y71 = tab71.Tab(2, 1:19);
% tab72 = load('alpha&gammaT6.mat', '-mat');
% x72 = [tab72.Tab(1, 1:13), 0.3, 0.25, 0.2, 0.15, 0.1, 0.05];
% y72 = [tab72.Tab(2, 1:13), 50*ones([1, 6])];
% tab73 = load('alpha&gammaT12.mat', '-mat');
% x73 = tab73.Tab(1, 1:19);
% y73 = tab73.Tab(2, 1:19);
% plot(x71, y71, '.-', x72, y72, '.-', x73, y73, '.-')
% xlabel('alpha = gamma');
% ylabel('Liczna prob potrzebnych do poprawnego przejechania toru');
% axis([0 1 0 55]);
% legend('T = 2', 'T = 6', 'T = 12');

% tab81 = load('alpha!=gammaT2.mat', '-mat');
% x81 = tab81.Tab(1, 1:19);
% y81 = tab81.Tab(2, 1:19);
% tab82 = load('alpha!=gammaT6.mat', '-mat');
% x82 = [tab82.Tab(1, 1:16), 0.85, 0.9, 0.95];
% y82 = [tab82.Tab(2, 1:16), 50, 50, 50];
% tab83 = load('alpha!=gammaT12.mat', '-mat');
% x83 = tab83.Tab(1, 1:19);
% y83 = tab83.Tab(2, 1:19);
% plot(x81, y81, '.-', x82, y82, '.-', x83, y83, '.-')
% xlabel('alpha i gamma (alpha = 1 - gamma)');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% axis([0 1 0 55]);
% legend('T = 2', 'T = 6', 'T = 12');
% %alpha rosnie, gamma maleje

% tab9 = load('strategia1', '-mat');
% x9 = [tab9.Tab(1, 1:11), 22, 24, 26, 28, 30];
% y9 = [tab9.Tab(2, 1:11), 50, 50, 50, 50, 50];
% plot(x9, y9, '.-');
% xlabel('T');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% axis([0 32 0 55]);
% for i = 1:numel(x9)
%     text(x9(i)-0.5, y9(i) + 1.5, sprintf('%.1f', y9(i)));
% end

% tab10 = load('strategia2', '-mat');
% x10 = [tab10.Tab(1, 1:9), 18, 20, 22, 24, 26, 28, 30]
% y10 = [tab10.Tab(2, 1:9), 50, 50, 50, 50, 50, 50, 50];
% plot(x10, y10, '.-');
% xlabel('T');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% axis([0 32 0 55]);
% for i = 1:numel(x10)
%     text(x10(i)-0.5, y10(i) + 1.5, sprintf('%.1f', y10(i)));
% end

% tab11 = load('strategia3', '-mat');
% x11 = tab11.Tab(1, 1:16);
% y11 = tab11.Tab(2, 1:16);
% plot(x11, y11, '.-');
% xlabel('T');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% axis([0 32 0 55]);
% for i = 1:numel(x11)
%     text(x11(i)-0.5, y11(i) + 1.5, sprintf('%.1f', y11(i)));
% end

% tab12= load('path1.mat', '-mat')
% x12 = [tab12.Tab(1, 1:8), 16, 18, 20, 22, 24, 26, 28, 30];
% y12 = [tab12.Tab(2, 1:8), 50*ones([1 8])];
% plot(x12, y12, '.-')
% xlabel('T');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% axis([0 32 0 55]);
% for i = 1:numel(x12)
%     text(x12(i)-0.5, y12(i) + 1.5, sprintf('%.1f', y12(i)));
% end 

% tab13= load('path2.mat', '-mat')
% x13 = tab13.Tab(1, 1:16);
% y13 = tab13.Tab(2, 1:16);
% plot(x13, y13, '.-')
% title('Liczba prob potrzebnych do poprawnego przejechania toru od warto�ci T');
% xlabel('T');
% ylabel('Liczba prob potrzebnych do poprawnego przejechania toru');
% axis([0 32 0 55]);
% for i = 1:numel(x13)
%     text(x13(i)-0.5, y13(i) + 1.5, sprintf('%.1f', y13(i)));
% end 
% 
% b = [-5 0 5 0 -5];
% a = [0, 1, 10, 1, 0];
% c = [5 5 5 5 5];
% d = [5 0 -5 0 5];
% 
% plot([-2 -1 0 1 2], a, [-2 -1 0 1 2], b, [-2 -1 0 1 2], c, [-2 -1 0 1 2], d)
% xticks([-2 -1 0 1 2]);
% xlabel('Numery czujnik�w');
% ylabel('Wartosci otrzymanej nagrody za aktywnosc czujnika');
% legend('Strategia 0', 'Strategia 1', 'Strategia 2', 'Strategia 3');
grid on;