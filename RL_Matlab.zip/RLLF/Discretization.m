function state = Discretization(sensors, stateSpace)
%Funckcja zwraca indeks state wektora sensors w tablicy stateSpace

    if(sensors(1) == 0)
        k1 = 0;
    else
        k1 = 1;
    end
    
    if(sensors(2) == 0)
        k2 = 0;
    else
        k2 = 1;
    end
    
    if(sensors(3) == 0)
        k3 = 0;
    else
        k3 = 1;
    end
    
    if(sensors(4) == 0)
        k4 = 0;
    else
        k4 = 1;
    end
    
    if(sensors(5) == 0)
        k5 = 0;
    else
        k5 = 1;
    end
    
    [~, state] = min(dist(stateSpace, [k1, k2, k3, k4, k5]'));
end