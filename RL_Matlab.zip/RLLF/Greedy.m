function a = Greedy(QTable, state, actions)
%Funkcja zwraca akcje wybrana metoda zachlanna

    %Wybor akcji
    if( sum(QTable(state, :)) == 0 )
        %Jesli agent znajduje sie poraz pierwszy w danym stanie, zwroc
        %losowa akcje
        a = randi([actions(1), actions(length(actions))], 1);      
    else  
       %Zwroc akcje o najwieksze Q-wartosci
       maxValue = max(QTable(state, :));
       for i=1:length(actions)
          if(QTable(state, i) == maxValue)
             a = actions(i);
          end
       end
    end 
end