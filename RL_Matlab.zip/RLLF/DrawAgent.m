function [phi, pos] = DrawAgent(agent, action, colors, phi, pos, beta, velocity)
%Funkcja oblicza polozenie i orientacje agenta w przestrzeni oraz rysuje go
    
    %Wybor skretu agenta w zaleznosci od wybranej akcji
    switch(action)
        
        %Mocny zakret w lewo
        case -2
            theta = 4*beta;
        
        %Lekki zakret w lewo
        case -1
            theta = beta;        
        
        %Jazdo naprzod
        case 0
            theta = 0;        
            
       %Lekki zakret w prawo    
        case 1
            theta = -beta;        
        
        %Mocny zakret w prawo
        case 2
            theta = -4*beta;
    end
    
    %Kat okreslajacy orientacje wzgledem globalnego ukladu wspolrzednych
    phi = phi + theta; 
    
    %Pobieranie wektora polozenia agenta, zmiana polozenie wedlug odpowiednich wzorow kinematycznych oraz przypisanie go w strukturze agenta 
    r = get(agent(1), 'Vertices');
    r(:, 1:2) = r(:, 1:2) + velocity*[cos(phi*pi/180)*ones(length(r), 1), sin(phi*pi/180)*ones(length(r), 1)];
    set(agent(1), 'XData', r(:,1), 'YData', r(:,2));
    
    %Pozycja srodka agenta
    pos(1) = (max(r(:, 1)) + min(r(:, 1)))/2;
    pos(2) = (max(r(:, 2)) + min(r(:, 2)))/2;
    
    %Zmiana polozen czujnikow
    for i = 2:6 
       %Pobieranie wektora polozenia czujnikow i zmienia polozenia wedlug
       %odpowiednich wzorow kinematycznych
       s = get(agent(i), 'Vertices');
       s(:, 1:2) = s(:, 1:2) + velocity*[cos(phi*pi/180)*ones(length(s), 1), sin(phi*pi/180)*ones(length(s), 1)];
       
       %Przypisanie zmienionego polozenia czujnikow z uwzglednieniem
       %kolorow
       if(colors(i - 1) == 0)
            set(agent(i), 'FaceColor', 'red', 'XData', s(:,1), 'YData', s(:,2)); 
       else
            set(agent(i), 'FaceColor', 'green', 'XData', s(:,1), 'YData', s(:,2)); 
       end
       
       %Wywolanie funkcji rotate na czujnikach
       rotate(agent(i),[0,0,1], theta, [(min(r(:, 1)) + max(r(:, 1)))/2, (min(r(:, 2)) + max(r(:, 2)))/2,0]); 
    end
end