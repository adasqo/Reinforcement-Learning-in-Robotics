function [xn, yn] =QuarterCircle(centre, radius, nPoints, quarter)
%Funkcja tworzy cwiercokrag tworzacy quarter cwiiartke ukladu wspolrzednych o srodku w pkt centre, promieniu radius skadajacy sie z nPoints punktach 

    theta = linspace(0,2*pi, nPoints);
    rho = ones(1, nPoints)*radius;
    [x, y] = pol2cart(theta, rho);
    x = x + centre(1);
    y = y + centre(2);
    
    xn = zeros(1, nPoints/4);
    yn = zeros(1, nPoints/4);
    
    %1 cwiartka
    if(quarter == 1)    
        xn = x(1:nPoints/4);
        yn = y(1:nPoints/4);
    %2 cwiartka    
    elseif(quarter == 2)    
        xn = x(nPoints/4 + 1:nPoints/2);
        yn = y(nPoints/4 + 1:nPoints/2);
    %3 cwiartka
    elseif(quarter == 3)    
        xn = x(nPoints/2 + 1:nPoints*3/4);
        yn = y(nPoints/2 + 1:nPoints*3/4);
    %4 cwiartka
    elseif(quarter == 4)    
        xn = x(nPoints*3/4 + 1:nPoints);
        yn = y(nPoints*3/4 + 1:nPoints);       
    end
end