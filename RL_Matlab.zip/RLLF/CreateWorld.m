function [plot, stadium, path, r] = CreateWorld(xlimit, ylimit, l, pathWidth, radius)
%Funkcja tworzy symulacje okienkowa

    close all;
    
    %Tworzenie okna gui, [x, y na ekarnie, szerokosc, wysokosc]
    figure('Position', [350, 60, 800, 700]); 
    
    %Tworzenie tab group
    hTab = uitabgroup; 
    
    %Tworzyenie zak�adki o tytule Q-table
    tab1 = uitab(hTab, 'title', 'QTable');

    %Tworzenie panelu w zakladce tab1
    QTablePanel = uipanel(tab1, 'title', 'QTable');

    %Tworzenie glownego wykresu, wektor zawiera [polozenie x i y, szerokosc]
    plot = axes('parent', QTablePanel,'XLim', xlimit, 'YLim', ylimit,'Box', 'on', ...
               'Position', [0.05, 0.1, 0.9, 0.85]); 
    
    %Liczba punktow tworzacych tor
    pathLength = 4000;

    %Tworzenie toru
    path1 = [linspace(5, 30, 1/5*pathLength)', -15*ones(1/5*pathLength, 1)];
    [path2x, path2y] = HalfCircle([30, -7.5], 7.5, 1/5*pathLength, 1); 
    path2 = [path2x; path2y]';
    [path3x, path3y] = HalfCircle([30, 5], 5, 1/5*pathLength, 3); 
    path3 = [path3x; path3y]';
    path4 = [linspace(30, 35, 1/20*pathLength)', 10*ones(1/20*pathLength, 1)];
    [path5x, path5y] = QuarterCircle([35, 12.5], 2.5, 1/10*pathLength, 4); 
    path5 = [path5x; path5y]';
    path6 = [37.5*ones(1/20*pathLength, 1), linspace(12.5, 20, 1/20*pathLength)'];
    path7 = [linspace(37.5, 20, 1/10*pathLength)', 20*ones(1/10*pathLength, 1)];
    path8 = [20*ones(1/10*pathLength, 1), linspace(20, 10, 1/10*pathLength)'];
    path9 = [linspace(20, 15, 1/20*pathLength)', 10*ones(1/20*pathLength, 1)];
    path10 = [linspace(15, 10, 1/20*pathLength)', linspace(10, 5, 1/20*pathLength)'];
    path11 = [linspace(10, 5, 1/20*pathLength)', 5*ones(1/20*pathLength, 1)];
    [path12x, path12y] = HalfCircle([0, 5], 5, 1/10*pathLength, 2);
    path12 = [path12x; path12y]';
    [path13x, path13y] = QuarterCircle([0, 5], 5, 1/20*pathLength, 3);
    path13 = [path13x; path13y]';
    path14 = [linspace(0, 10, 1/40*pathLength)', 0*ones(1/40*pathLength, 1)];
    path15 = [10*ones(1/10*pathLength, 1), linspace(0, -5, 1/10*pathLength)'];
    path16 = [linspace(10, 0, 1/20*pathLength)', -5*ones(1/20*pathLength, 1)];
    [path17x, path17y] = HalfCircle([0, -10], 5, 1/10*pathLength, 3);
    path17 = [path17x; path17y]';
    path18 = [linspace(0, 5, 1/20*pathLength)', -15*ones(1/20*pathLength, 1)];

    path = [path1; path2; path3; path4; path5; path6; path7; path8; path9; path10; path11; path12; path13; path14; path15; path16; path17; path18];
    
    %Tworzenie plaszczyzny i toru
    arena = patch([-l*2/5, -l*2/5, 2*l - 5, 2*l - 5],[-l, l, l, -l], 'w');                    
    
    %Tworzenie lewej krawedzi toru
    path1_l = patch([5, 30] ,[-15 + pathWidth/2, -15 + pathWidth/2], 'w');
    [path2x_l, path2y_l] = HalfCircle([30, -7.5], 7.5 - pathWidth/2, 1/5*pathLength, 1); 
    path2_l = patch(path2x_l, path2y_l, 'w'); 
    set(path2_l, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/10*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path2x_l, 'YData', path2y_l);
    [path3x_l, path3y_l] = HalfCircle([30, 5], 5 + pathWidth/2, 1/5*pathLength, 3); 
    path3_l = patch(path3x_l, path3y_l, 'w'); 
    set(path3_l, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/10*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path3x_l, 'YData', path3y_l);
    path4_l = patch([30, 35], [10 + pathWidth/2, 10 + pathWidth/2], 'w');
    [path5x_l, path5y_l] = QuarterCircle([35, 12.5], 2.5 - pathWidth/2, 1/10*pathLength, 4); 
    path5_l = patch(path5x_l, path5y_l, 'w'); 
    set(path5_l, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/40*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path5x_l, 'YData', path5y_l);
    path6_l = patch([37.5 - pathWidth/2, 37.5 - pathWidth/2] ,[12.5, 20 - pathWidth/2], 'w');
    path7_l = patch([37.5 - pathWidth/2, 20 + pathWidth/2] ,[20 - pathWidth/2, 20 - pathWidth/2], 'w');
    path8_l = patch([20 + pathWidth/2, 20 + pathWidth/2] ,[20 - pathWidth/2, 10 - pathWidth/2], 'w');
    path9_l = patch([20 + pathWidth/2, 15] ,[10 - pathWidth/2, 10 - pathWidth/2], 'w');
    path10_l = patch([15, 10] ,[10 - pathWidth/2, 5 - pathWidth/2], 'w');
    path11_l = patch([10, 5 - pathWidth/2] ,[5 - pathWidth/2, 5 - pathWidth/2], 'w'); 
    path11_l_additional = patch([5 - pathWidth/2, 5 - pathWidth/2] ,[5 - pathWidth/2, 5 + pathWidth/2], 'w'); 
    [path12x_l, path12y_l] = HalfCircle([0, 5], 5 - pathWidth/2, 1/5*pathLength, 2); 
    path12_l = patch(path12x_l, path12y_l, 'w'); 
    set(path12_l, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/10*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path12x_l, 'YData', path12y_l);
    [path13x_l, path13y_l] = QuarterCircle([0, 5], 5 - pathWidth/2, 1/10*pathLength, 3); 
    path13_l = patch(path13x_l, path13y_l, 'w'); 
    set(path13_l, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/40*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path13x_l, 'YData', path13y_l);
    path14_l = patch([0, 10 + pathWidth/2] ,[0 + pathWidth/2, 0 + pathWidth/2], 'w');
    path15_l = patch([10 + pathWidth/2, 10 + pathWidth/2], [0 + pathWidth/2, -5 - pathWidth/2], 'w');
    path16_l = patch([10 + pathWidth/2, 0], [-5 - pathWidth/2, -5 - pathWidth/2], 'w');
    [path17x_l, path17y_l] = HalfCircle([0, -10], 5 - pathWidth/2, 1/5*pathLength, 3); 
    path17_l = patch(path17x_l, path17y_l, 'w'); 
    set(path17_l, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/10*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path17x_l, 'YData', path17y_l); 
    path18_l = patch([0, 5], [-15 + pathWidth/2, -15 + pathWidth/2], 'w');

    %Tworzenie prawej krawedzi toru
    path1_r = patch([5, 30] ,[-15 - pathWidth/2, -15 - pathWidth/2], 'w');
    [path2x_r, path2y_r] = HalfCircle([30, -7.5], 7.5 + pathWidth/2, 1/5*pathLength, 1); 
    path2_r = patch(path2x_r, path2y_r, 'w'); 
    set(path2_r, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/10*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path2x_r, 'YData', path2y_r);
    [path3x_r, path3y_r] = HalfCircle([30, 5], 5 - pathWidth/2, 1/5*pathLength, 3); 
    path3_r = patch(path3x_r, path3y_r, 'w'); 
    set(path3_r, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/10*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path3x_r, 'YData', path3y_r);
    path4_r = patch([30, 35], [10 - pathWidth/2, 10 - pathWidth/2], 'w');
    [path5x_r, path5y_r] = QuarterCircle([35, 12.5], 2.5 + pathWidth/2, 1/10*pathLength, 4); 
    path5_r = patch(path5x_r, path5y_r, 'w'); 
    set(path5_r, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/40*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path5x_r, 'YData', path5y_r);
    path6_r = patch([37.5 + pathWidth/2, 37.5 + pathWidth/2] ,[12.5, 20 + pathWidth/2], 'w');
    path7_r = patch([37.5 + pathWidth/2, 20 - pathWidth/2] ,[20 + pathWidth/2, 20 + pathWidth/2], 'w');
    path8_r = patch([20 - pathWidth/2, 20 - pathWidth/2] ,[20 + pathWidth/2, 10 + pathWidth/2], 'w');
    path9_r = patch([20 - pathWidth/2, 15] ,[10 + pathWidth/2, 10 + pathWidth/2], 'w');
    path10_r = patch([15, 10] ,[10 + pathWidth/2, 5 + pathWidth/2], 'w');
    path11_r = patch([10, 5 + pathWidth/2] ,[5 + pathWidth/2, 5 + pathWidth/2], 'w');  
    [path12x_r, path12y_r] = HalfCircle([0, 5], 5 + pathWidth/2, 1/5*pathLength, 2); 
    path12_r = patch(path12x_r, path12y_r, 'w'); 
    set(path12_r, 'Facecolor', 'none', 'FaceVertexCData', [ones(10, 3); zeros(1/10*pathLength - 11, 3); ones(1, 3)], 'EdgeColor', 'flat', 'XData', path12x_r, 'YData', path12y_r);
    [path13x_r, path13y_r] = QuarterCircle([0, 5], 5 + pathWidth/2, 1/10*pathLength, 3); 
    path13_r = patch(path13x_r, path13y_r, 'w'); 
    set(path13_r, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/40*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path13x_r, 'YData', path13y_r);
    path14_r = patch([0, 10 - pathWidth/2] ,[0 - pathWidth/2, 0 - pathWidth/2], 'w');
    path15_r = patch([10 - pathWidth/2, 10 - pathWidth/2], [0 - pathWidth/2, -5 + pathWidth/2], 'w');
    path16_r = patch([10 - pathWidth/2, 0], [-5 + pathWidth/2, -5 + pathWidth/2], 'w');
    [path17x_r, path17y_r] = HalfCircle([0, -10], 5 + pathWidth/2, 1/5*pathLength, 3); 
    path17_r = patch(path17x_r, path17y_r, 'w'); 
    set(path17_r, 'Facecolor', 'none', 'FaceVertexCData', [zeros(1/10*pathLength - 1, 3); 1 1 1], 'EdgeColor', 'flat', 'XData', path17x_r, 'YData', path17y_r); 
    path18_r = patch([0, 5], [-15 - pathWidth/2, -15 - pathWidth/2], 'w');
    
    stadium = arena;
    
    %Utworzenie agenta
    %Wspolrzedne poczatkowe agenta
    [X,Y] = Circle([5, -15], radius, 100);                        
    agent = patch(X, Y, 'b');                                   
    
    %Tworzenie czujnikow
    [X1, Y1] = Circle([5 + radius*cos(pi/4), -15 + radius*sin(pi/4)], 0.2*radius, 50); 
    L1 = patch(X1, Y1, 'g');
    [X2, Y2] = Circle([5 + radius*cos(pi/8), -15 + radius*sin(pi/8)], 0.2*radius, 50); 
    L2 = patch(X2, Y2, 'g');
    [X3, Y3] = Circle([5 + radius*cos(0), -15 + radius*sin(0)], 0.2*radius, 50); 
    L3 = patch(X3, Y3, 'g');
    [X4, Y4] = Circle([5 + radius*cos(-pi/8), -15 + radius*sin(-pi/8)], 0.2*radius, 50); 
    L4 = patch(X4, Y4, 'g');
    [X5, Y5] = Circle([5 + radius*cos(-pi/4), -15 + radius*sin(-pi/4)], 0.2*radius, 50); 
    L5 = patch(X5, Y5, 'g');
    
    r = [agent, L1, L2, L3, L4, L5];  
end