function stateSpace = CreateStateSpace()
%Funckja tworzy macierz stateSpace zlozona z wszystkich kombinacji wskazan z
%czujnikow

    %Utworzenie macierzy stanu
    k1 = [0;1];
    k2 = [0;1];
    k3 = [0;1];
    k4 = [0;1];
    k5 = [0;1];

    stateSpace = SetProd(k1, k2, k3, k4, k5);

end