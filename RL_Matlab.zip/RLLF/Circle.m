function [x, y] = Circle(centre, radius, nPoints)
%Funkcja tworzy okrag o srodku w pkt centre, promieniu radius skladajacy sie z nPoints punktow 

    %Inicjalizacja
    theta = linspace(0, 2*pi, nPoints);
    rho = ones(1, nPoints)*radius;
    
    %Wektory x i y przechowuja wspolrzedne kolejnych punktow na okregu
    [x, y] = pol2cart(theta, rho);
    x = x + centre(1);
    y = y + centre(2);
    
end