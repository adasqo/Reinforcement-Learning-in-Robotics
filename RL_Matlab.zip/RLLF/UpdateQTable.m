function Q = UpdateQTable(state, a, reward, Q, nextState, alpha, gamma)
%Funkcja odswieza tabele Q-wartosci

    Q(state, a + 3) = (1 - alpha)*Q(state, a + 3) + alpha*(reward + gamma*max(Q(nextState,:)));
end