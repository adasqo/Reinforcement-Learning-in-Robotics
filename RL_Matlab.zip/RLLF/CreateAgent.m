function r = CreateAgent(radius)
%Funckja tworzy strukture Patch agenta  

    %Wspolrzedne poczatkowe agenta
    [X,Y] = Circle([5, -15], radius, 100);                        
    agent = patch(X, Y, 'b');                                   
    
    %Tworzenie czujnikow
    [X1, Y1] = Circle([5 + radius*cos(pi/4), -15 + radius*sin(pi/4)], 0.2*radius, 50);  
    L1 = patch(X1, Y1, 'g');
    [X2, Y2] = Circle([5 + radius*cos(pi/8), -15 + radius*sin(pi/8)], 0.2*radius, 50); 
    L2 = patch(X2, Y2, 'g');
    [X3, Y3] = Circle([5 + radius*cos(0), -15 + radius*sin(0)], 0.2*radius, 50); 
    L3 = patch(X3, Y3, 'g');
    [X4, Y4] = Circle([5 + radius*cos(-pi/8), -15 + radius*sin(-pi/8)], 0.2*radius, 50); 
    L4 = patch(X4, Y4, 'g');
    [X5, Y5] = Circle([5 + radius*cos(-pi/4), -15 + radius*sin(-pi/4)], 0.2*radius, 50); 
    L5 = patch(X5, Y5, 'g');
    
    r = [agent, L1, L2, L3, L4, L5];    
end