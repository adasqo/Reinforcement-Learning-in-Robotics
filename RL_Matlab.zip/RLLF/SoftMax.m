function a = SoftMax(QTable, state, actions, T)
%Funkcja zwraca akcje wyznaczona za pomoca rozkladu Boltzmann'a

    %Inicjalizacja zmiennych
    random = rand();
    
    %Tworzenie wektora przechowujacego wartosci rozkaladu Boltzmann'a
    P = exp(QTable(state,:)./T)./sum(exp(QTable(state,:)./T));
    
    %Wybor akcji
    if( find(isnan(P),1) ~= 0 )
       %Jesli agent znajduje sie pierwszy raz w danym stanie 
       a = randi([actions(1), actions(length(actions))], 1);      
    else  
        if(random < P(1))
            a = -2;
        elseif(random >= P(1) && random < sum([P(1),P(2)]))
            a = -1;
        elseif(random >= sum([P(1),P(2)]) && random < sum([P(1),P(2),P(3)]))
            a = 0;
        elseif(random >= sum([P(1),P(2),P(3)]) && random < sum([P(1),P(2),P(3),P(4)]))
            a = 1;
        elseif(random >= sum([P(1),P(2),P(3),P(4)]) && random <= sum([P(1),P(2),P(3),P(4),P(5)]))
            a = 2;
        end
    end 
end