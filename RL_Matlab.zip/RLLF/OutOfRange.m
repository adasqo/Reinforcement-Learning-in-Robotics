function i = OutOfRange(sensors)
%Funkcja sprawdza, czy agent znajduje sie w obrebie toru 
    if(sum(sensors(1:5)) == 0)
        i = 0;
    else
        i = 1;
    end
end