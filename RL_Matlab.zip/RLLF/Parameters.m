%Skrypt zawirajacy parametry, wymiary, zalozenia

global mode;
mode = '';
global figure;
figure = true;

%Parametry symulacji dla metody Q-table
maxTrials = 50;     
maxSteps = 5000;      

n = 1;                        
x = 0;                      
y = 0; 
i = 0;
k = 1;
reward = 0;        
out = 0;
flag = 1;

%Pozycja poczatkowa
posInit = [5, -15]';
pos = posInit;

%Elementarny kat obrotu robota
beta = 3;

%Predkosc ruchu
velocity = 0.1;
    
%Wymiary robota
radius = 2;

%Wymiary swiata
pathWidth = 1;

%Inicjalizacja metody Q-learning
stateSpace = CreateStateSpace();
actions = [-2 -1 0 1 2];
nStates = size(stateSpace, 1);
nActions = length(actions);
QTable = zeros(nStates, nActions);   

%Inicjalizacja parametrow wyboru akcji
T = 2;
eps = 0.15;

%Inicjalizacja wspolczynnikow alpha i gamma
alpha = 0.9;
gamma = 0.9;

%Inicjalizacja wykresow i GUI
l = 25;
xlimit = [-l*2/5, 2*l - 5];
ylimit = [-l, l];
pathLength = 4000;

% GUI
[plot, stadium, path, agent] = CreateWorld(xlimit, ylimit, l, pathWidth, radius);
