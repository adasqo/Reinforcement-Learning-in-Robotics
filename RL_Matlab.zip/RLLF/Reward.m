function reward = Reward(sensor, licz, out)
%Funkcja zwraca nagrode na podstawie wartosci czujnikow
    
    %Poczatkowa wartosc nagrody
    reward = 0;
    
    %Przyznanie nagrody
    if(sensor(1) == 1)
        reward = reward + 0;
    end
    if(sensor(2) == 1)
        reward = reward + 1;
    end
    if(sensor(3) == 1)
        reward = reward + 10;
    end
    if(sensor(4) == 1)
        reward = reward + 1;
    end
    if(sensor(5) == 1)
        reward = reward + 0;
    end
       
   %Jesli agent znajduje sie poza linia
   if(licz > 0)
       reward = -10;
   end
   
   %Jesli agent znajduje sie poza linia przez kilka krokow
   if(out == 1)
        reward = -50;
   end
end