function dist = Distance(sensor, path, pathLength)
%Funckcja zwraca najmniejsza odleglosc miedzy punktem o wspolrzednych
%sensor a punktami z wektora path

    %Inicjalizacja
    distVector = zeros(pathLength, 1);
    
    %Obliczenie odleglosci kazdego punktu
    for i=1:pathLength
        distVector(i) = sqrt((sensor(1) - path(i, 1))^2 + (sensor(2) - path(i, 2))^2); 
    end
    %Wybor najmnijeszej odleglosci
    dist = min(distVector);
    
end