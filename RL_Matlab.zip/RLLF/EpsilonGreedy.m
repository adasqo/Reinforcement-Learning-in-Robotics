function a = EpsilonGreedy(QTable, state, actions, eps)
%Funkcja zwraca akcje wybrana metoda epsilon-zachlanna

    %Inicjalizacja
    random = rand();
    
    %Wybor akcji - losowa akcja z prawdopodobienstwem eps, w przeciwnym
    %wypadku zachlanny wybor akcji
    if(random < eps)
        a = randi([actions(1), actions(length(actions))], 1);
    else
       maxValue = max(QTable(state, :));
       for i=1:length(actions)
          if(QTable(state, i) == maxValue)
             a = actions(i);
          end
       end
    end
end